# Eric Lam's Udacity Portfolio Project

## Getting Started
Everything should work out of the box. Open index.html for the website!

## Technology Stack
* bootstrap
* grunt: responsive_images
* html
* css
